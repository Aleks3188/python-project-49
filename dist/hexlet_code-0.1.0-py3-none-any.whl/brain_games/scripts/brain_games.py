#!/home/admin_ar/hexlet-git/python-project-49/.venv/bin/python
from brain_games.cli import welcome_user

def main():
    None

if __name__ == '__main__':
    main()