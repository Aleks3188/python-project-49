### Hexlet tests and linter status:
[![Actions Status](https://github.com/Aleks3188/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Aleks3188/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/6b8ad49399a0b9a5aa30/maintainability)](https://codeclimate.com/github/Aleks3188/python-project-49/maintainability)