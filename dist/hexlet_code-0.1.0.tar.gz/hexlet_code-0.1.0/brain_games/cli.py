#!/usr/bin/env python3
import prompt
def welcome_user():
    print(f"brain-games\nWelcome to the Brain Games!")
    name_gamer = prompt.string('May I have your name?')




welcome_user() 